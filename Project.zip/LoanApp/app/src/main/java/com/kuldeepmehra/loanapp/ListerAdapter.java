package com.kuldeepmehra.loanapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.ListAdapter;

import java.util.List;

public class ListerAdapter extends ArrayAdapter {
    private Activity mcontxt;
    List<Admin>adminList;
    public ListerAdapter(Activity mcontxt,List<Admin>adminList){
        super(mcontxt,R.layout.list_item,adminList);
        this.mcontxt=mcontxt;
        this.adminList=adminList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=mcontxt.getLayoutInflater();
        View listItemView = inflater.inflate(R.layout.list_item,null,true);
        TextView name=listItemView.findViewById(R.id.name);
        TextView type=listItemView.findViewById(R.id.type);
        TextView number=listItemView.findViewById(R.id.number);
        TextView pan=listItemView.findViewById(R.id.pan);
        TextView mob=listItemView.findViewById(R.id.mob);
        TextView amt=listItemView.findViewById(R.id.amt);

        Admin admin=adminList.get(position);

        name.setText(admin.getName());
        type.setText(admin.getType());
        number.setText(admin.getNumber());
        pan.setText(admin.getPan());
        mob.setText(admin.getMob());
        amt.setText(admin.getAmt());

        return listItemView;

    }
}

package com.kuldeepmehra.loanapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Admn extends AppCompatActivity {
    EditText txt1,txt2;
    Button btn1;
    TextView agnt;
    String id="Admin";
    String pass="Admin@123";
    String ck,ck1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admn);
        txt1=findViewById(R.id.txt1);
        txt2=findViewById(R.id.txt2);
        btn1=findViewById(R.id.btn1);
        agnt=findViewById(R.id.agnt);
        agnt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Admn.this,MainActivity.class);
                startActivity(intent);
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ck=txt1.getText().toString();
                ck1=txt2.getText().toString();

                if (TextUtils.isEmpty(txt1.getText()))
                {
                    Toast.makeText(Admn.this, "ID is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(txt2.getText()))
                {
                    Toast.makeText(Admn.this, "Password is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (ck.equals(id)&& ck1.equals(pass))
                {
                    Intent intent =new Intent(Admn.this,Data_fech.class);
                    startActivity(intent);
                    txt1.setText("");
                    txt2.setText("");
                }
                else
                {
                    Toast.makeText(Admn.this, "Invalid Data", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
package com.kuldeepmehra.loanapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Data_fech extends AppCompatActivity {
    ListView list_admin;
    List<Admin>adminList;

    DatabaseReference admin_rf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_fech);
        list_admin=findViewById(R.id.list_admin);
        adminList=new ArrayList<>();
        admin_rf= FirebaseDatabase.getInstance().getReference("Admin");
        admin_rf.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                adminList.clear();

                for (DataSnapshot adminSnapsh:dataSnapshot.getChildren())
                {
                    Admin admin=adminSnapsh.getValue(Admin.class);
                    adminList.add(admin);

                }
                List_Adp listAdapter=new List_Adp(Data_fech.this,adminList);
                list_admin.setAdapter(listAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
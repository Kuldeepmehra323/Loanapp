package com.kuldeepmehra.loanapp;

public class Admin {

    String name,type,number,pan,mob,amt;

    public Admin(String name, String type, String number, String pan, String mob, String amt) {
        this.name = name;
        this.type = type;
        this.number = number;
        this.pan = pan;
        this.mob = mob;
        this.amt = amt;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getNumber() {
        return number;
    }

    public String getPan() {
        return pan;
    }

    public String getMob() {
        return mob;
    }

    public String getAmt() {
        return amt;
    }
}




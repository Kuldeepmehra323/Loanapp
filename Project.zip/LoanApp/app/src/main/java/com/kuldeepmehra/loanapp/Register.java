package com.kuldeepmehra.loanapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {
    Button btn1;
    EditText txt1,txt2,txt3,txt4,txt5,txt6;
    RadioButton rd1,rd2;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        btn1=findViewById(R.id.btn1);
        txt1=findViewById(R.id.txt1);
        txt2=findViewById(R.id.txt2);
        txt3=findViewById(R.id.txt3);
        txt4=findViewById(R.id.txt4);
        txt5=findViewById(R.id.txt5);
        txt6=findViewById(R.id.txt6);
        rd1=findViewById(R.id.rd1);
        rd2=findViewById(R.id.rd2);

        databaseReference= FirebaseDatabase.getInstance().getReference().child("Admin");

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(txt1.getText()))
                {
                    Toast.makeText(Register.this, "Name is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(txt2.getText()))
                {
                    Toast.makeText(Register.this, "Policy Type  is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(txt3.getText()))
                {
                    Toast.makeText(Register.this, " Policy No is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(txt4.getText()))
                {
                    Toast.makeText(Register.this, "PAN is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(txt5.getText()))
                {
                    Toast.makeText(Register.this, "Mobile No is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(txt6.getText()))
                {
                    Toast.makeText(Register.this, "Amount is Mandatory", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    Toast.makeText(Register.this, "Register", Toast.LENGTH_SHORT).show();

                    insertdata();

                    txt1.setText("");
                    txt2.setText("");
                    txt3.setText("");
                    txt4.setText("");
                    txt5.setText("");
                    txt6.setText("");

                }

            }
        });

    }

    private void insertdata() {

        String name=txt1.getText().toString();
        String type=txt2.getText().toString();
        String number=txt3.getText().toString();
        String pan=txt4.getText().toString();
        String mob=txt5.getText().toString();
        String amt=txt6.getText().toString();
        Admin admin=new Admin(name,type,number,pan,mob,amt);
        databaseReference.push().setValue(admin);
        Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();

    }
}
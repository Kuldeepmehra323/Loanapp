package com.kuldeepmehra.loanapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class List_Adp extends ArrayAdapter {

    private Activity mcontext;
    List<Admin>adminList;

    public List_Adp(Activity mcontext,List<Admin>adminList){
        super(mcontext,R.layout.list_file,adminList);
        this.mcontext=mcontext;
        this.adminList=adminList;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
//        return super.getView(position, convertView, parent);
        LayoutInflater inflater=mcontext.getLayoutInflater();
        View listview=inflater.inflate(R.layout.list_file,null,true);
        TextView name=listview.findViewById(R.id.name);
        TextView type=listview.findViewById(R.id.type);
        TextView number=listview.findViewById(R.id.number);
        TextView pan=listview.findViewById(R.id.pan);
        TextView mob=listview.findViewById(R.id.mob);
        TextView amt=listview.findViewById(R.id.amt);
        Admin admin=adminList.get(position);

        name.setText(admin.getName());
        type.setText(admin.getType());
        number.setText(admin.getNumber());
        pan.setText(admin.getPan());
        mob.setText(admin.getMob());
        amt.setText(admin.getAmt());

        return listview;


    }
}

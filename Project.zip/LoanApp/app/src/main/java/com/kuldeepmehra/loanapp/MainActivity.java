package com.kuldeepmehra.loanapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {
    Button btn1;
    TextView admin;
    EditText txt1,txt2;
    String id="Agent";
    String pass="Agent@123";
    String ck,ck1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn1=findViewById(R.id.btn1);
        admin=findViewById(R.id.admin);
        txt1=findViewById(R.id.txt1);
        txt2=findViewById(R.id.txt2);


//        databaseReference= FirebaseDatabase.getInstance().getReference().child("admin");



        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ck=txt1.getText().toString();
                ck1=txt2.getText().toString();

                if (TextUtils.isEmpty(txt1.getText()))
                {
                    Toast.makeText(MainActivity.this, "ID is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(txt2.getText()))
                {
                    Toast.makeText(MainActivity.this, "Password is Mandatory", Toast.LENGTH_SHORT).show();
                }
                else if (ck.equals(id)&& ck1.equals(pass))
                {
                    Intent intent =new Intent(MainActivity.this,Register.class);
                    startActivity(intent);
                    txt1.setText("");
                    txt2.setText("");
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Invalid Data", Toast.LENGTH_SHORT).show();
                }


//                else
//                {
//                 Intent intent =new Intent(MainActivity.this,Register.class);
//                 startActivity(intent);
//                    txt1.setText("");
//                    txt2.setText("");
//                }
            }
        });

        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent obj=new Intent(MainActivity.this,Admn.class);
                startActivity(obj);
            }
        });
    }

//    private void insertdata() {
//        String id=txt1.getText().toString();
//        String pass=txt2.getText().toString();

//        Admin admin=new Admin(id,pass);
//        databaseReference.push().setValue(admin);




    }
